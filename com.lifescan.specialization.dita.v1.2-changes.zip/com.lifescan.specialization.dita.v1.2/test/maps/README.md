# LifeScan DITA Specialization Test Suite

This test suite demonstrates and validates the LifeScan DITA 1.2 Specialization Plugin. It includes comprehensive examples of all available specializations, custom attributes, character entities, and domain support.

## Overview

The LifeScan DITA plugin extends standard DITA 1.2 with specialized attributes and character entities designed specifically for medical device documentation. This test suite provides examples of how to use these specializations effectively.

## Test Files Structure

```
lifescan-specialization-test/
├── lifescan-test-bookmap.ditamap    # BookMap with LifeScan attributes
├── lifescan-test-map.ditamap        # Map with LifeScan attributes
├── topics/
│   ├── introduction.dita            # Comprehensive overview topic
│   ├── getting-started.dita         # Concept topic
│   ├── device-setup.dita            # Task topic
│   ├── testing-procedures.dita      # Procedure topic
│   ├── troubleshooting.dita         # Troubleshooting topic
│   ├── maintenance.dita             # Maintenance topic
│   ├── specifications.dita          # Reference topic
│   ├── glossary.dita                # Glossary topic
│   └── legal-notices.dita           # Legal information topic
└── README.md                        # This file
```

## LifeScan Specializations Demonstrated

### 1. Custom Profiling Attributes

The plugin provides four custom attributes for content profiling:

- **`supportedproducts`** - Include content only when specific products are supported
  - Example: `supportedproducts="OneTouch Verio, OneTouch Verio Flex"`
  
- **`itemtype`** - Include content only for a specific type of publication
  - Example: `itemtype="manual"`
  
- **`feature`** - Identify content relevant to a product feature (for launchdarkly flags)
  - Example: `feature="advanced-testing"`
  
- **`deliveryTarget`** - Specify the intended media (print, screen, etc.)
  - Example: `deliveryTarget="print screen"`

**Note:** These attributes are currently available on map and bookmap elements, as well as topicref elements within maps. They are not yet available on individual topic elements due to incomplete DTD implementation.

### 2. Character Entities

The plugin provides extensive character entity support for medical and technical documentation:

#### Currency & Financial
- `&cent;` (¢) - Cent symbol
- `&pound;` (£) - Pound sterling  
- `&euro;` (€) - Euro symbol

#### Mathematical & Comparison
- `&le;` (≤) - Less than or equal to
- `&ge;` (≥) - Greater than or equal to
- `&plusmn;` (±) - Plus-minus sign
- `&divide;` (÷) - Division sign
- `&times;` (×) - Multiplication sign
- `&deg;` (°) - Degree symbol
- `&micro;` (µ) - Micro symbol

#### Punctuation & Typography
- `&emdash;` (—) - Em dash
- `&endash;` (–) - En dash
- `&ldquo;` (") - Left double quotation mark
- `&rdquo;` (") - Right double quotation mark
- `&lsquo;` (') - Left single quotation mark
- `&rsquo;` (') - Right single quotation mark
- `&iexcl;` (¡) - Inverted exclamation mark
- `&iquest;` (¿) - Inverted question mark
- `&nbhyphen;` (‑) - Non-breaking hyphen

#### Special Characters
- `&reg;` (®) - Registered trademark
- `&trade;` (™) - Trademark symbol
- `&nbsp;` ( ) - Non-breaking space
- `&wordjoiner;` () - Word joiner

#### UI & Interactive Elements
- `&ballotbox;` (☐) - Empty ballot box
- `&ballotboxwithx;` (☑) - Ballot box with check mark
- `&ballotboxwithch;` (☒) - Ballot box with X mark
- `&whitecircle;` (○) - White circle
- `&warning;` (⚠) - Warning symbol

### 3. Domain Support

The plugin includes support for standard DITA domains:

- **Highlight Domain** - For text highlighting and emphasis
- **Utilities Domain** - For utility elements and metadata
- **Indexing Domain** - For content indexing and search
- **Hazard Statement Domain** - For safety information and warnings
- **Abbreviated Form Domain** - For abbreviations and acronyms
- **Programming Domain** - For code elements and syntax
- **Software Domain** - For software-related content
- **User Interface Domain** - For UI elements and interactions

## Document Types Available

The plugin provides specialized DTDs for:

- **`LifeScan_bookmap.dtd`** - BookMap specialization with LifeScan attributes
- **`LifeScan_map.dtd`** - Map specialization with LifeScan attributes
- **`LifeScan_topic.dtd`** - Base topic specialization
- **`LifeScan_concept.dtd`** - Concept topic specialization
- **`LifeScan_task.dtd`** - Task topic specialization
- **`LifeScan_reference.dtd`** - Reference topic specialization

## Current Limitations and Issues

### 1. Incomplete Topic DTD Implementation

The LifeScan profiling attributes (`supportedproducts`, `itemtype`, `feature`, `deliveryTarget`) are currently only available on map and bookmap elements. They are not available on individual topic elements due to incomplete DTD implementation.

**Workaround:** Use the attributes on topicref elements within maps to achieve content profiling at the topic level.

### 2. Missing Entity Files

Some DTD files reference entity files that are not included in the plugin:
- `technicalContent/dtd/task.ent`
- `technicalContent/dtd/reference.ent`
- Various domain entity files

This causes validation errors when using concept, task, and reference DTDs.

**Workaround:** Use the base topic DTD (`LifeScan_topic.dtd`) for all topic types until the missing entity files are provided.

### 3. Character Entity Limitations

Some character entities that would be useful for medical documentation are not defined:
- `&minus;` (minus sign)
- `&copy;` (copyright symbol)

**Workaround:** Use numeric character references (e.g., `&#8722;` for minus) or plain text alternatives.

## Testing the Plugin

### Prerequisites

1. DITA-OT 4.2.1 or later
2. Java 11 or later
3. The LifeScan DITA plugin installed

### Installation

1. Copy the plugin files to your DITA-OT plugins directory
2. Run the plugin installation command:
   ```bash
   dita install
   ```

### Validation

To validate the test files:

```bash
# Validate the bookmap
dita --input=lifescan-test-bookmap.ditamap --format=validate

# Validate the map
dita --input=lifescan-test-map.ditamap --format=validate

# Validate individual topics
dita --input=topics/introduction.dita --format=validate
```

### Transformation

To transform the test files:

```bash
# Transform to PDF
dita --input=lifescan-test-bookmap.ditamap --format=pdf

# Transform to HTML
dita --input=lifescan-test-bookmap.ditamap --format=html5

# Transform to HTML with specific product filtering
dita --input=lifescan-test-bookmap.ditamap --format=html5 --args.filter="OneTouch Verio"
```

## Content Profiling Examples

The test files demonstrate various content profiling scenarios:

### Product-Specific Content

```xml
<topicref href="topics/device-setup.dita" 
          supportedproducts="OneTouch Verio, OneTouch Verio Flex"
          itemtype="manual"
          feature="device-configuration"/>
```

### Feature-Flagged Content

```xml
<topicref href="topics/troubleshooting.dita" 
          supportedproducts="OneTouch Verio, OneTouch Verio Flex"
          itemtype="manual"
          feature="support-tools"/>
```

### Multi-Product Content

```xml
<topicref href="topics/introduction.dita" 
          supportedproducts="OneTouch Verio, OneTouch Verio Flex, OneTouch Verio Reflect"
          itemtype="manual"
          feature="user-onboarding"/>
```

## Best Practices

1. **Consistent Profiling:** Apply LifeScan attributes consistently across your documentation set
2. **Character Entities:** Use LifeScan character entities for mathematical expressions and medical terminology
3. **Domain Support:** Leverage standard DITA domains for specialized content
4. **Testing:** Verify content filtering works correctly with different product and feature combinations
5. **Documentation:** Document your profiling strategy and attribute usage guidelines

## Future Enhancements

To improve the LifeScan DITA plugin, consider:

1. **Complete Topic DTD Implementation:** Add LifeScan attributes to all topic DTDs
2. **Missing Entity Files:** Provide all referenced entity files
3. **Additional Character Entities:** Add more medical and mathematical symbols
4. **Validation Tools:** Create tools to validate LifeScan attribute usage
5. **Documentation:** Provide comprehensive usage guidelines and examples

## Support

For issues with the LifeScan DITA plugin or this test suite, please refer to the main plugin documentation or contact the LifeScan technical documentation team.

## License

This test suite is provided as-is for testing and demonstration purposes. The content is fictional and intended only for testing the LifeScan DITA specializations. 