#!/bin/bash

# LifeScan DITA 1.2 Specialization Plugin - Per-file Validation Script
# Validates each demo topic/map using xmllint with the project's XML catalog

# Do not exit on first error; we want to report all results
set +e

THIS_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$THIS_SCRIPT_DIR/.." && pwd)"
TEST_DIR="$PROJECT_DIR/test"
TEST_OUTPUT_DIR="$TEST_DIR/test-output"

mkdir -p "$TEST_OUTPUT_DIR"

# Logger setup
. "$THIS_SCRIPT_DIR/lib/testlog.sh"

# Enable file and console logs
# Respect prior settings if a parent script already configured logging.
export BASHLOG_STD_LEVEL=${BASHLOG_STD_LEVEL:-INFO}
export BASHLOG_FILE_LEVEL=${BASHLOG_FILE_LEVEL:-DEBUG}
export BASHLOG_FILE_PATH=${BASHLOG_FILE_PATH:-"$TEST_OUTPUT_DIR/test-pre-validate.log"}
#export BASHLOG_JSON_LEVEL=${BASHLOG_JSON_LEVEL:-DEBUG}
#export BASHLOG_JSON_PATH=${BASHLOG_JSON_PATH:-"$TEST_OUTPUT_DIR/validate.json"}

# Project catalog file(s) to use for validation
export SGML_CATALOG_FILES="$PROJECT_DIR/catalog.xml"

# Check xmllint availability
if ! command -v xmllint >/dev/null 2>&1; then
	log warn "xmllint not found. Skipping XML validation tests."
	log info "To enable validation, ensure libxml2-utils (xmllint) is installed."
	log_suite_start "Pre-Build DITA Validation Tests (Skipped)"
	log info "XML validation skipped - xmllint not available"
	log_suite_end
	log info "Test results: SKIPPED (xmllint not available)"
	exit 0
fi

# Collect files to validate (only the newly added demo files)
shopt -s nullglob
declare -a FILES=()
for pattern in \
	"$PROJECT_DIR/test/maps/topics/*.dita" \
	"$PROJECT_DIR/test/maps/lifescan-specializations-demo*.ditamap" \
	"$PROJECT_DIR/test/maps-classic/topics/*.dita" \
	"$PROJECT_DIR/test/maps-classic/lifescan-specializations-demo*.ditamap"; do
	for f in $pattern; do
		FILES+=("$f")
	done
done
shopt -u nullglob

if [ ${#FILES[@]} -eq 0 ]; then
	log warn "No demo files found to validate."
	exit 0
fi

# Start suite and report
log_suite_start "Pre-Build DITA Validation Tests"
log info "LifeScan DITA 1.2 Specialization Plugin Validation Tests"
log info "Validating grammar and catalogs using xmllint"
log info "Generated: $(date)"
log info "Catalog(s): $SGML_CATALOG_FILES"
log info ""

total=${#FILES[@]}
passed=0
failed=0

for file in "${FILES[@]}"; do
	relpath="${file#$PROJECT_DIR/}"
	log_test_start "Validate '$relpath'"
	# Validate quietly; console shows only PASS/FAIL via logger
	if command -v timeout >/dev/null 2>&1; then
		timeout 30s xmllint --catalogs --noout --nonet --valid --loaddtd --dtdattr "$file" >/dev/null 2>&1
		status=$?
	else
		xmllint --catalogs --noout --nonet --valid --loaddtd --dtdattr "$file" >/dev/null 2>&1
		status=$?
	fi
	if [ $status -eq 0 ]; then
		log_test_pass
		passed=$((passed+1))
	elif [ $status -eq 124 ]; then
		# Re-run with catalog and entity debug, with 60-second timeout and save output to debug log
		log_file="$TEST_OUTPUT_DIR/debug-pre-validate-$(echo "$relpath" | tr '/\\: ' '____').log"
		log_test_timeout
		failed=$((failed+1))

		# Re-run with catalog and entity debug, with 60-second timeout and save output to debug log
		log debug "Re-running validation with debug options..."
		echo -e '###' > "$log_file" 2>&1
		echo -e '#  SGML_CATALOG_FILES=$SGML_CATALOG_FILES' >> "$log_file" 2>&1
		echo -e '#  XML_DEBUG_CATALOG=1 ' >> "$log_file" 2>&1
		echo -e '#  timeout 60s xmllint --noout --nonet --valid --loaddtd --dtdattr --debugent --catalogs "$file"' >> "$log_file" 2>&1
		echo -e '###' > "$log_file" 2>&1
		echo -e ' ' > "$log_file" 2>&1
		XML_DEBUG_CATALOG=1 timeout 60s xmllint --noout --nonet --valid --loaddtd --dtdattr --debugent --catalogs "$file" >> "$log_file" 2>&1

		log debug "Debug details written to: $log_file"
	else
		# Re-run with catalog debug and entity debug and save output to debug log
		log_file="$TEST_OUTPUT_DIR/debug-pre-validate-$(echo "$relpath" | tr '/\\: ' '____').log"
		log_test_fail
		failed=$((failed+1))

		# Re-run with catalog and entity debug, with 60-second timeout and save output to debug log
		log debug "Re-running validation with debug options..."
		echo -e '###' > "$log_file" 2>&1
		echo -e '#  SGML_CATALOG_FILES=$SGML_CATALOG_FILES' >> "$log_file" 2>&1
		echo -e '#  XML_DEBUG_CATALOG=1 ' >> "$log_file" 2>&1
		echo -e '#  xmllint --noout --nonet --valid --loaddtd --dtdattr --debugent --catalogs "$file"' >> "$log_file" 2>&1
		echo -e '###' > "$log_file" 2>&1
		echo -e ' ' > "$log_file" 2>&1
		XML_DEBUG_CATALOG=1 xmllint --noout --nonet --valid --loaddtd --dtdattr --debugent --catalogs "$file" >> "$log_file" 2>&1

		log debug "Debug details written to: $log_file"
	fi
done


# End suite and exit non-zero if any failures
log_suite_end
log info "Test results in file: '$BASHLOG_FILE_PATH'"
if [ $failed -gt 0 ]; then
	log info "Debug log files were generated in: '$TEST_OUTPUT_DIR'"
	exit 2
fi

exit 0


