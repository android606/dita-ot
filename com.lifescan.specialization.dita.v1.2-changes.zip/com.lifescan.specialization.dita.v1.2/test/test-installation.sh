#!/bin/bash

# LifeScan DITA 1.2 Specialization Plugin - Installation Test Script
# This script tests the installation and functionality of the plugin

set -e  # Exit on any error

# Get the directory where this script is located
THIS_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$THIS_SCRIPT_DIR/.." && pwd)"

# Configuration
TEST_DIR="$PROJECT_DIR/test"
TEST_OUTPUT_DIR="$TEST_DIR/test-output"
DITA_OT_VERSION="3.7.3"
DITA_OT_DIR="$PROJECT_DIR/dita-ot"
PLUGIN_ID="com.lifescan.specialization.dita.v1.2"
DEBUG="true"

mkdir -p "$TEST_OUTPUT_DIR"

# Logger setup (shared with other tests)
. "$THIS_SCRIPT_DIR/lib/testlog.sh"

# Enable file and console logs
export BASHLOG_STD_LEVEL=${BASHLOG_STD_LEVEL:-INFO}
export BASHLOG_FILE_LEVEL=${BASHLOG_FILE_LEVEL:-DEBUG}
export BASHLOG_FILE_PATH=${BASHLOG_FILE_PATH:-"$TEST_OUTPUT_DIR/test-installation.log"}
[ "$DEBUG" = "true" ] && export BASHLOG_DEBUG=${BASHLOG_DEBUG:-1}

cd "$TEST_DIR"  # Move to the test directory

# Deprecated print helpers replaced by structured logger in test/lib/testlog.sh

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check Java version
check_java_version() {
    if command_exists java; then
        local java_version=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2)
        local major_version=$(echo "$java_version" | cut -d'.' -f1)
        
        if [ "$major_version" = "1" ]; then
            # Handle Java 8 format (1.8.0_xxx)
            major_version=$(echo "$java_version" | cut -d'.' -f2)
        fi
        
        # DITA-OT 3.7.3 requires Java 8+
        if [ "$major_version" -lt 8 ]; then
            log warn "DITA-OT ${DITA_OT_VERSION} requires Java 8 or later. Found Java $java_version"
            log warn "The test may fail due to Java version incompatibility."
            return 1
        fi
        
        log debug "Java version check passed: $java_version"
        return 0
    else
        log error "Java is not installed"
        return 1
    fi
}
# Function to check if a plugin is installed
check_plugin_installed() {
    local plugin_id="$1"
    
    if [ -z "$plugin_id" ]; then
        log error "Plugin ID is required for checking installation status"
        return 2
    fi

    if "$DITA_OT_DIR/bin/dita" plugins | grep -q "$plugin_id"; then
        log debug "Plugin '$plugin_id' is installed"
        return 0
    elif [ -e "$DITA_OT_DIR/plugins/$plugin_id" ]; then
        log debug "Plugin '$plugin_id' is not installed, but exists in plugins directory"
        return 2
    else
        log debug "Plugin '$plugin_id' is not installed"
        return 1
    fi

}

# Function to remove a plugin by ID and confirm removal
remove_plugin_by_id() {
    local plugin_id="$1"
    log debug "Removing plugin: $plugin_id"

    local is_installed=true
    local is_removed=false

    if [ -z "$plugin_id" ]; then
        log error "Plugin ID is required for removal"
        return 1
    fi
    
    # Check if plugin exists before attempting removal
    if ! "$DITA_OT_DIR/bin/dita" plugins | grep -q "$plugin_id"; then
        log debug "Plugin '$plugin_id' not installed"
        is_installed=false
    else # Plugin is installed, try to remove it
        if "$DITA_OT_DIR/bin/dita" uninstall $plugin_id; then
            log debug "dita uninstall command completed"
            is_installed=false
        fi
   fi

    # Does the plugin folder still exist?
    if [ -e "$DITA_OT_DIR/plugins/$plugin_id" ]; then
        log debug "Plugin '$plugin_id' exists in plugins directory"
        log warn "Attempting to remove plugin '$plugin_id' manually"
        rm -rf "$DITA_OT_DIR/plugins/$plugin_id"

        if [ -e "$DITA_OT_DIR/plugins/$plugin_id" ]; then
            log error "Plugin '$plugin_id' folder still present after manual removal attempt"
            return 2
        else
            log debug "Plugin folder '$plugin_id' removed successfully"
            # Run 'dita install' to complete the manual removal process
            "$DITA_OT_DIR/bin/dita" install
            is_removed=true
        fi
    else
        # Plugin folder is not present
        is_removed=true
    fi
    
    if [ "$is_installed" = false ] && [ "$is_removed" = true ]; then
        log debug "Plugin '$plugin_id' removed successfully"    
        return 0
    else
        log error "Plugin '$plugin_id' could not be removed"
        return 1
    fi
}

# Function to install a plugin by repository URL or local zip file and get the ID
install_plugin_from_url() {
    local source="$1"
    
    if [ -z "$source" ]; then
        log error "Plugin source URL is required"
        return 1
    fi
    
    log debug "Installing plugin from: $source"
    
    # Install the plugin
    # Capture the output of dita install to get the plugin ID
    local install_output
    install_output=$("$DITA_OT_DIR/bin/dita" install "$source" 2>&1)
    if [ $? -eq 0 ]; then
        log debug "Plugin install command completed"
        
        # Extract plugin ID from "Added <plugin_id>" output
        local plugin_id
        plugin_id=$(echo "$install_output" | grep "Added" | sed 's/Added //')
        
        # Verify installation by running `dita plugins` command
        if "$DITA_OT_DIR/bin/dita" plugins | grep -q "$plugin_id"; then
            log debug "Plugin '$plugin_id' installed successfully"
            return 0
        else
            log error "Plugin '$plugin_id' did not install successfully"
            return 1
        fi
    else
        log error "dita install command failed: $install_output"
        return 1
    fi
}

# Function to install a plugin by ID using known pre-set plugin repos and registries
install_plugin_by_id_from_registry() {
    local plugin_id="$1"
    
    if [ -z "$plugin_id" ]; then
        log error "Plugin ID is required for installation"
        return 1
    fi
    
    log debug "Installing plugin by ID: $plugin_id"
    
    # Check if plugin is already installed
    if "$DITA_OT_DIR/bin/dita" plugins | grep -q "$plugin_id"; then
        log debug "Plugin '$plugin_id' already installed"
        return 0
    fi

    # Try to install from registry
    if "$DITA_OT_DIR/bin/dita" install "$plugin_id"; then
        return 0
    fi
    
    # If registry installation failed, try known plugin repositories
    log warn "Plugin '$plugin_id' not found in dita-ot registry, falling back on known repositories..."
    
    # Known plugin repositories and their patterns
    declare -A plugin_map
    plugin_map=(
        ["org.oasis-open.dita.v1_2"]="https://github.com/dita-ot/org.oasis-open.dita.v1_2/archive/1.2.1.zip"
        ["org.oasis-open.dita.v1_3"]="https://github.com/dita-ot/org.oasis-open.dita.v1_3/archive/1.3.1.zip"
        ["org.oasis-open.dita.v1_3-legacy"]="https://github.com/dita-ot/org.oasis-open.dita.v1_3/archive/1.3.0.zip"
    )
    
    # Check if plugin ID exists in our map
    if [[ -n "${plugin_map[$plugin_id]}" ]]; then
        log debug "Found plugin '$plugin_id' in known repositories"
        if install_plugin_from_url "${plugin_map[$plugin_id]}"; then
            return 0
        fi
    fi
    log error "Failed to install plugin '$plugin_id' from any known source"
    return 1
}

# Function to clone and setup DITA-OT
install_dita_ot() {
    # Check if DITA-OT directory already exists
    if [ -d "$DITA_OT_DIR" ]; then
        log debug "DITA-OT found at '$DITA_OT_DIR'"
        
        # Try to get DITA-OT version
        if version=$("$DITA_OT_DIR/bin/dita" --version 2>/dev/null); then
            if echo "$version" | grep -qi "^DITA-OT version 3\.7\."; then
                log debug "'$version' verified"
                return 0
            else
                log warn "Installed DITA-OT version string is '$version'. Test scripts are designed for dita-ot 3.7.x and may not work correctly."
                return 0
            fi
        else
            log warn "Failed to verify version of installed DITA-OT, removing existing installation"
            rm -rf "$DITA_OT_DIR"
        fi
    fi

    # Clone DITA-OT from repo
    if command_exists git; then
        git clone https://git.android606.com/android/dita-ot.git "$DITA_OT_DIR"
        if [ $? -ne 0 ]; then
            log error "Failed to clone DITA-OT repository from 'https://git.android606.com/android/dita-ot.git'"
            exit 1
        fi

    else
        log error "git not found. Script cannot continue."
        exit 1
    fi
    
    # Set permissions
    chmod +x "$DITA_OT_DIR/bin/dita"
    chmod +x "$DITA_OT_DIR/bin/ant"

    # Try to get DITA-OT version after cloning
    if version=$("$DITA_OT_DIR/bin/dita" --version 2>/dev/null); then
        if echo "$version" | grep -qi "^DITA-OT version 3\.7\."; then
            log debug "'$version' verified"
            return 0
        else
            log warn "Newly cloned DITA-OT version string is '$version', expected 3.7.x. Please update the test scripts to match the new version."
            return 0
        fi
    else
        log error "Failed to verify version of newly installed DITA-OT. Cannot continue."
        exit 1
    fi

    log debug "DITA-OT installed successfully"
    return 0
}

# Function to setup plugin dependencies
setup_plugin_dependencies() {
    log debug "Fixing up plugin conflicts/dependencies..."
    
    # Remove the classic plugin if it exists using the new function
    if check_plugin_installed "com.lifescan.specialization.dita.v1.2.classic"; then
        if remove_plugin_by_id "com.lifescan.specialization.dita.v1.2.classic"; then
            log debug "Conflicting Classic Lifescan DITA 1.2 plugin removed"
        fi
    fi
    
    # Check if org.oasis-open.dita.v1_2 plugin exists
    if check_plugin_installed "org.oasis-open.dita.v1_2"; then
        if remove_plugin_by_id "org.oasis-open.dita.v1_2"; then
            log debug "Conflicting OASIS DITA 1.2 plugin removed"
        fi
    fi

    log debug "Plugin conflicts/dependencies checked and fixed"
    return 0
}

# Function to check build requirements
check_build_requirements() {
    log debug "Checking build requirements..."
    
    # Check if ant is available
    if ! command -v ant >/dev/null 2>&1; then
        log warn "Apache Ant not found. Checking if build.xml can use java directly..."
        
        # Check if we can use java directly instead
        if ! command -v java >/dev/null 2>&1; then
            log error "Neither Ant nor Java found. Cannot build plugin."
            return 1
        fi
        
        log debug "Java found, will attempt build despite missing Ant"
    else
        local ant_version=$(ant -version 2>&1 | head -n 1)
        log debug "Ant available: $ant_version"
    fi
    
    return 0
}

# Function to build the plugin package
build_plugin_package() {
    log debug "Building plugin: $PLUGIN_ID..."

    # Check build requirements first
    if ! check_build_requirements; then
        log error "Build requirements not met"
        exit 1
    fi

    # Build and package our plugin then install the package
    local plugin_zip="$PROJECT_DIR/dist/${PLUGIN_ID}.zip"

    if bash "$PROJECT_DIR/build.sh"; then
        log debug "Build complete. Looking for package..."
    else
        log error "build.sh failed"
        exit 1;
    fi

    if [ -f "$plugin_zip" ]; then
        log debug "Found package '$plugin_zip'"
        return 0
    else
        log error "Package not found after build. We can't test a plugin that won't build."
        exit 1
    fi

    log debug "Plugin '$PLUGIN_ID' built successfully"
    return 0
}


# Function to reinstall the plugin under test
setup_plugin_under_test() {
    log debug "Installing plugin under test: $PLUGIN_ID ..."
    THIS_PLUGIN_DIR="$DITA_OT_DIR/plugins/$PLUGIN_ID"

    # Check if plugin is already installed
    check_plugin_installed "$PLUGIN_ID"
    echo "CHECK PLUGIN INSTALLED RETURNED: $?" 
    if [ $? -eq 0 ]; then
        log debug "Plugin '$PLUGIN_ID' is already installed, removing..."
        if remove_plugin_by_id "$PLUGIN_ID"; then
            log debug "Existing plugin '$PLUGIN_ID' removed"
        else
            log error "Failed to remove existing plugin"
            exit 1
        fi
    elif [ $? -eq 2 ]; then
        log error "Plugin '$PLUGIN_ID' is not installed, but folder '$THIS_PLUGIN_DIR' could not be removed."
        exit 1
    else
        log debug "Plugin '$PLUGIN_ID' is not installed"
    fi

    # Install the plugin package
    local plugin_zip="$PROJECT_DIR/dist/${PLUGIN_ID}.zip"
    if [ -f "$plugin_zip" ]; then
        log debug "Found package '$plugin_zip'."
        if ! install_plugin_from_url "$plugin_zip"; then
            log error "Failed to install plugin from '$plugin_zip'"
            exit 1
        fi
    else
        log error "We can't find the plugin zip file. Path to zip: '$plugin_zip'"
        exit 1
    fi
    

    # Verify installation
    if ! check_plugin_installed "$PLUGIN_ID"; then
        log error "Plugin '$PLUGIN_ID' failed to install. Cannot continue."
        exit 1
    fi

    log debug "Plugin '$PLUGIN_ID' installed successfully"
    return 0
}




# Function to clean up
cleanup() {
    log info "Cleaning up test files..."
    
    if [ "${1:-}" = "full" ]; then
        # Full cleanup - remove DITA-OT
        if [ -d "$DITA_OT_DIR" ]; then
            rm -rf "$DITA_OT_DIR"
            log info "DITA-OT removed"
        fi
        
        if [ -f "dita-ot-${DITA_OT_VERSION}.zip" ]; then
            rm "dita-ot-${DITA_OT_VERSION}.zip"
            log info "DITA-OT zip file removed"
        fi
    fi
    
    # Remove test output
    if [ -d "$TEST_OUTPUT_DIR" ]; then
        log info "Removing test output directory: $TEST_OUTPUT_DIR"
        rm -rf "$TEST_OUTPUT_DIR"
    fi
}

# Main execution
main() {
    log_suite_start "Installation Tests"
    log info "Starting LifeScan DITA 1.2 Specialization Plugin test suite..."
    
    # Check prerequisites
    log_test_start "Check Java version"
    if check_java_version; then
        log_test_pass
    else
        log_test_fail
    fi
    
    # Build plugin package
    log_test_start "Build plugin package"
    if build_plugin_package; then
        log_test_pass
    else
        log_test_fail
    fi

    # Run tests
    log_test_start "Install DITA-OT"
    if install_dita_ot; then
        log_test_pass
    else
        log_test_fail
    fi

    log_test_start "Setup plugin dependencies"
    if setup_plugin_dependencies; then
        log_test_pass
    else
        log_test_fail
    fi

    log_test_start "Install plugin under test"
    if setup_plugin_under_test; then
        log_test_pass
    else
        log_test_fail
    fi
    
    log info "All tests completed."
    
    # Show results
    echo ""
    log_suite_end
    log info "Test output available in: '$TEST_OUTPUT_DIR'"
}

# Handle command line arguments
case "${1:-}" in
    "clean")
        cleanup full
        ;;
    "clean-test")
        cleanup
        ;;
    "help"|"-h"|"--help")
        echo "Usage: $0 [clean|clean-test|help]"
        echo ""
        echo "Commands:"
        echo "  (no args)  Run full installation test"
        echo "  clean      Remove DITA-OT and all test files"
        echo "  clean-test Remove only test output files"
        echo "  help       Show this help message"
        ;;
    *)
        main
        ;;
esac 