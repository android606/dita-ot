# Test Scripts

This directory contains all test scripts and related files for the LifeScan DITA 1.2 Specialization Plugin.

## Files

- **`test-installation.sh`** - Bash script for Linux/macOS testing

## Usage

### From the project root:

```bash
# Linux/macOS
./test/test-installation.sh
```
