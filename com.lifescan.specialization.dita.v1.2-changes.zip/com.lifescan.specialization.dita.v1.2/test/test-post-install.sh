#!/bin/bash

# LifeScan DITA 1.2 Specialization Plugin - Post-Installation Test Script
# This script tests the plugin functionality after installation

set -e  # Exit on any error

THIS_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$THIS_SCRIPT_DIR/.." && pwd)"
TEST_DIR="$PROJECT_DIR/test"
TEST_OUTPUT_DIR="$TEST_DIR/test-output"
DITA_OT_DIR="$PROJECT_DIR/dita-ot"
PLUGIN_ID="com.lifescan.specialization.dita.v1.2"

mkdir -p "$TEST_OUTPUT_DIR"

# Logger setup
. "$THIS_SCRIPT_DIR/lib/testlog.sh"

# Enable file and console logs
export BASHLOG_STD_LEVEL=${BASHLOG_STD_LEVEL:-INFO}
export BASHLOG_FILE_LEVEL=${BASHLOG_FILE_LEVEL:-DEBUG}
export BASHLOG_FILE_PATH=${BASHLOG_FILE_PATH:-"$TEST_OUTPUT_DIR/test-post-install.log"}
export BASHLOG_DEBUG=1

cd "$TEST_DIR"  # Move to the test directory

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}


# Test validation of //OASIS// map
test_oasis_map() {
    log debug "Test //OASIS// map"
    # Execute dita validate-1.2 on the test map
    if "$DITA_OT_DIR/bin/dita" -f validate-1.2 -i "$TEST_DIR/maps-classic/lifescan-specializations-demo.ditamap" -o "$TEST_OUTPUT_DIR" -v -d; then
        return 0
    else
        return 1
    fi
}

# Test validation of //OASIS// bookmap
test_oasis_bookmap() {
    log debug "Test //OASIS// bookmap"
    # Execute dita validate-1.2 on the test map
    if "$DITA_OT_DIR/bin/dita" -f validate-1.2 -i "$TEST_DIR/maps-classic/lifescan-specializations-demo-bookmap.ditamap" -o "$TEST_OUTPUT_DIR"; then
        return 0
    else
        return 1
    fi
}

# Test validation of //LIFESCAN// map
test_lifescan_map() {
    log debug "Test //LIFESCAN// map"
    # Execute dita validate-1.2 on the test map
    if "$DITA_OT_DIR/bin/dita" -f validate-1.2 -i "$TEST_DIR/maps/lifescan-specializations-demo.ditamap" -o "$TEST_OUTPUT_DIR"; then
        return 0
    else
        return 1
    fi
}

# Test validation of //LIFESCAN// bookmap
test_lifescan_bookmap() {
    log debug "Test //LIFESCAN// bookmap"
    # Execute dita validate-1.2 on the test map
    if "$DITA_OT_DIR/bin/dita" -f validate-1.2 -i "$TEST_DIR/maps/lifescan-specializations-demo-bookmap.ditamap" -o "$TEST_OUTPUT_DIR"; then
        return 0
    else
        return 1
    fi
}

# Function to test catalog functionality

# Main execution
main() {
    log_suite_start "Post-Installation Tests"
    log info "Starting LifeScan DITA 1.2 Plugin post-installation tests..."
    
    # Test plugin functionality
    log_test_start "Test //OASIS// map validation"
    if test_oasis_map; then
        log_test_pass
    else
        log_test_fail
    fi
    
    log_test_start "Test //OASIS// bookmap validation"
    if test_oasis_bookmap; then
        log_test_pass
    else
        log_test_fail
    fi
    
    log_test_start "Test //LIFESCAN// map validation"
    if test_lifescan_map; then
        log_test_pass
    else
        log_test_fail
    fi
    
    log_test_start "Test //LIFESCAN// bookmap validation"
    if test_lifescan_bookmap; then
        log_test_pass
    else
        log_test_fail
    fi
    
    log info "All post-installation tests completed."
    
    # Show results
    echo ""
    log_suite_end
    log info "Test output available in: $TEST_OUTPUT_DIR"
}

# Handle command line arguments
case "${1:-}" in
    "help"|"-h"|"--help")
        echo "Usage: $0 [help]"
        echo ""
        echo "Commands:"
        echo "  (no args)  Run post-installation tests"
        echo "  help       Show this help message"
        ;;
    *)
        main
        ;;
esac

exit 0
