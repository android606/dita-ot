#!/bin/bash

set -uo pipefail;

function _log_exception() {
  (
    BASHLOG_FILE_LEVEL=OFF;
    BASHLOG_JSON_LEVEL=OFF;
    BASHLOG_SYSLOG_LEVEL=OFF;

    log 'ERROR' "Logging Exception: ${@}";
  );
}

# ANSI color codes
C_BLACK='\033[30m'
C_RED='\033[31m'
C_GREEN='\033[32m'
C_YELLOW='\033[33m'
C_BLUE='\033[34m'
C_MAGENTA='\033[35m'
C_CYAN='\033[36m'
C_GRAY='\e[38;5;240m'
C_SILVER='\e[38;5;251m'
C_WHITE='\e[38;5;255m'
C_ORANGE='\e[38;5;208m'
# Bold
CB_BLACK='\033[1;30m'
CB_RED='\033[1;31m'
CB_GREEN='\033[1;32m'
CB_YELLOW='\033[1;33m'
CB_BLUE='\033[1;34m'
CB_MAGENTA='\033[1;35m'
CB_CYAN='\033[1;36m'
CB_SILVER='\033[1;38;5;251m'
CB_WHITE='\033[1;38;5;255m'
CB_ORANGE='\033[1;38;5;208m'
# Reset
C_RESET='\033[0m'


function log() {
  local date_format="${BASHLOG_DATE_FORMAT:-+%F %T}";
  local date="$(date "${date_format}")";
  local date_s="$(date "+%s")";

  local file_path="${BASHLOG_FILE_PATH:-/tmp/$(basename "${0}").log}";
  local json_path="${BASHLOG_JSON_PATH:-/tmp/$(basename "${0}").log.json}";

  local tag="${BASHLOG_SYSLOG_TAG:-$(basename "${0}")}";
  local facility="${BASHLOG_SYSLOG_FACILITY:-local0}";
  local pid="${$}";

  local msg_level="${1}";
  local msg_level_upper="$(echo "${msg_level}" | awk '{print toupper($0)}')";

  local debug_level="${BASHLOG_DEBUG:-1}";

  shift 1;

  local line="${@}";

  # RFC 5424
  #
  # Numerical         Severity
  #   Code
  #
  #    0       Emergency: system is unusable
  #    1       Alert: action must be taken immediately
  #    2       Critical: critical conditions
  #    3       Error: error conditions
  #    4       Warning: warning conditions
  #    5       Notice: normal but significant condition
  #    6       Informational: informational messages
  #    7       Debug: debug-level messages

  local -A severities;
  severities['DEBUG']=7;
  severities['START']=6;
  severities['PASS']=6;
  severities['FAIL']=6;
  severities['SKIP']=6;
  severities['TIMEOUT']=6;
  severities['INFO']=6;
  severities['NOTICE']=5; # Unused
  severities['WARN']=4;
  severities['ERROR']=3;
  severities['CRIT']=2;   # Unused
  severities['ALERT']=1;  # Unused
  severities['EMERG']=0;  # Unused
  severities['OFF']=-1;    # OFF is a special value that disables the sink

  # Default log thresholds for each sink
  export BASHLOG_STD_LEVEL=${BASHLOG_STD_LEVEL:-INFO};
  export BASHLOG_FILE_LEVEL=${BASHLOG_FILE_LEVEL:-INFO};
  export BASHLOG_JSON_LEVEL=${BASHLOG_JSON_LEVEL:-OFF};
  export BASHLOG_SYSLOG_LEVEL=${BASHLOG_SYSLOG_LEVEL:-OFF};
  export BASHLOG_DEBUG=${BASHLOG_DEBUG:-0};


  local msg_severity="${severities[${msg_level_upper}]:-3}";  # Set message severity or use ERROR by default
  # If the message severity is not valid, log an error
  if ! [[ -v severities[${msg_level_upper}] ]]; then
    log error "testlog.sh: Undefined log level '${msg_level_upper}' used when trying to log: ${@}";
    exit 1;
  fi;

  # Per-sink thresholds with explicit OFF/empty to disable.
  # STDOUT (console) sink threshold
  local std_upper="$(echo "${BASHLOG_STD_LEVEL-}" | awk '{print toupper($0)}')";
  local std_enabled=1;
  local std_threshold="${severities[${std_upper}]:-6}"; # Set sink threshold or use 6 (INFO) by default

  # if message severity is less than or equal to the threshold, 
  # or is DEBUG and debug level is greater than 0, enable stdout
  if [ "${msg_severity}" -le "${std_threshold}" ]; then
    std_enabled=1;
  elif [ "${msg_severity}" -eq "${severities['DEBUG']}" ] && [ "${debug_level}" -gt 0 ]; then
    std_enabled=1;
  else
    std_enabled=0;
  fi;


  # FILE sink threshold
  local file_upper="$(echo "${BASHLOG_FILE_LEVEL-}" | awk '{print toupper($0)}')";
  local file_enabled=0;
  local file_threshold="${severities[${file_upper}]:-6}"; # Set sink threshold or use 6 (INFO) by default

  if [ "${msg_severity}" -le "${file_threshold}" ]; then
    file_enabled=1;
  elif [ "${msg_severity}" -eq "${severities['DEBUG']}" ] && [ "${debug_level}" -gt 0 ]; then
    file_enabled=1;
  else
    file_enabled=0;
  fi;


  # JSON sink threshold (will not get debug messages unless sink threshold is DEBUG)
  local json_upper="$(echo "${BASHLOG_JSON_LEVEL-}" | awk '{print toupper($0)}')";
  local json_enabled=0;
  local json_threshold="${severities[${json_upper}]}"; # Set sink threshold

  if [ "${msg_severity}" -le "${json_threshold}" ]; then
    json_enabled=1;
  else
    json_enabled=0;
  fi;


  # SYSLOG sink threshold (will not get debug messages unless sink threshold is DEBUG)
  local syslog_upper="$(echo "${BASHLOG_SYSLOG_LEVEL-}" | awk '{print toupper($0)}')";
  local syslog_enabled=0;
  local syslog_threshold="${severities[${syslog_upper}]}"; # Set sink threshold or use INFO by default

  if [ "${msg_severity}" -le "${syslog_threshold}" ]; then
    syslog_enabled=1;
  else
    syslog_enabled=0;
  fi;

  if [ "${syslog_enabled}" -eq 1 ]; then
    local syslog_line="${msg_level_upper}: ${line}";

    logger \
      --id="${pid}" \
      -t "${tag}" \
      -p "${facility}.${msg_severity}" \
      "${syslog_line}" \
      || _log_exception "logger --id=\"${pid}\" -t \"${tag}\" -p \"${facility}.${msg_severity}\" \"${syslog_line}\"";
  fi;

  if [ "${file_enabled}" -eq 1 ]; then
    local file_line="${date} [${msg_level_upper}] ${line}";
    echo -e "${file_line}" >> "${file_path}" \
      || _log_exception "echo -e \"${file_line}\" >> \"${file_path}\"";
  fi;

  if [ "${json_enabled}" -eq 1 ]; then
    local json_line="$(printf '{"timestamp":"%s","level":"%s","message":"%s"}' "${date_s}" "${msg_level}" "${line}")";
    echo -e "${json_line}" >> "${json_path}" \
      || _log_exception "echo -e \"${json_line}\" >> \"${json_path}\"";
  fi;

  # Color codes for each log level
  local -A colours;
  colours['DEBUG']=${CB_MAGENTA}
  colours['INFO']=${CB_BLUE}
  colours['START']=${CB_WHITE}
  colours['PASS']=${CB_GREEN}
  colours['NOTICE']=${C_GRAY}
  colours['WARN']=${CB_YELLOW}
  colours['ERROR']=${CB_RED}
  colours['FAIL']=${CB_RED}
  colours['CRIT']=${CB_RED}
  colours['ALERT']=${CB_ORANGE}
  colours['EMERG']=${CB_ORANGE}

  local level_colour="${colours[${msg_level_upper}]:-${CB_WHITE}}";

  local std_line="${C_GRAY}${date} ${level_colour}[${msg_level_upper}] ${C_SILVER}${line}${C_RESET}";

  # Standard Output (Pretty)
  # ERROR messages are sent to stderr, all other messages are sent to stdout
  if [ "${std_enabled}" -eq 1 ] && [ "${msg_level_upper}" = "ERROR" ]; then
    echo -e "${std_line}" >&2;
  elif [ "${std_enabled}" -eq 1 ]; then
    echo -e "${std_line}";
  fi;

}


# --------------------------------
# Test suite and test case helpers
# --------------------------------

declare __BASHLOG_SUITE_NAME="${__BASHLOG_SUITE_NAME:-}";
declare __BASHLOG_TEST_NAME="${__BASHLOG_TEST_NAME:-}";
declare -i __BASHLOG_SUITE_START_S=${__BASHLOG_SUITE_START_S:-0};
declare -i __BASHLOG_TEST_START_S=${__BASHLOG_TEST_START_S:-0};
declare -i __BASHLOG_COUNT_PASS=${__BASHLOG_COUNT_PASS:-0};
declare -i __BASHLOG_COUNT_FAIL=${__BASHLOG_COUNT_FAIL:-0};
declare -i __BASHLOG_COUNT_SKIP=${__BASHLOG_COUNT_SKIP:-0};
declare -i __BASHLOG_COUNT_ERROR=${__BASHLOG_COUNT_ERROR:-0};
declare -i __BASHLOG_COUNT_TIMEOUT=${__BASHLOG_COUNT_TIMEOUT:-0};

function log_suite_start() {
  __BASHLOG_SUITE_NAME="${1:-suite}";
  __BASHLOG_SUITE_START_S="$(date +%s)";
  __BASHLOG_TEST_NAME="";
  __BASHLOG_TEST_START_S=0;
  __BASHLOG_COUNT_PASS=0;
  __BASHLOG_COUNT_FAIL=0;
  __BASHLOG_COUNT_SKIP=0;
  __BASHLOG_COUNT_ERROR=0;
  __BASHLOG_COUNT_TIMEOUT=0;
  log info "SUITE START: ${__BASHLOG_SUITE_NAME}";
}

function log_test_start() {
  __BASHLOG_TEST_NAME="${1:-test}";
  __BASHLOG_TEST_START_S="$(date +%s)";
  log start "${__BASHLOG_TEST_NAME}";
}

function _bashlog__test_end_core() {
  local status_upper="$(echo "${1:-PASS}" | awk '{print toupper($0)}')";
  shift 1;
  local msg_suffix="${*:-}";

  local now_s="$(date +%s)";
  local duration_s=0;
  if [ "${__BASHLOG_TEST_START_S}" -gt 0 ]; then
    duration_s=$(( now_s - __BASHLOG_TEST_START_S ));
  fi;

  case "${status_upper}" in
    'PASS')
      __BASHLOG_COUNT_PASS=$(( __BASHLOG_COUNT_PASS + 1 ));
      log pass "${__BASHLOG_TEST_NAME} (${duration_s}s) ${msg_suffix}";
      ;;
    'FAIL')
      __BASHLOG_COUNT_FAIL=$(( __BASHLOG_COUNT_FAIL + 1 ));
      log fail "${__BASHLOG_TEST_NAME} (${duration_s}s) ${msg_suffix}";
      ;;
    'SKIPPED'|'SKIP')
      __BASHLOG_COUNT_SKIP=$(( __BASHLOG_COUNT_SKIP + 1 ));
      log skip "${__BASHLOG_TEST_NAME} ${msg_suffix}";
      ;;
    'ERROR')
      __BASHLOG_COUNT_ERROR=$(( __BASHLOG_COUNT_ERROR + 1 ));
      log error "${__BASHLOG_TEST_NAME} (${duration_s}s) ${msg_suffix}";
      ;;
    'TIMEOUT')
      __BASHLOG_COUNT_TIMEOUT=$(( __BASHLOG_COUNT_TIMEOUT + 1 ));
      log timeout "${__BASHLOG_TEST_NAME} (${duration_s}s) ${msg_suffix}";
      ;;
    *)
      log warn "UNKNOWN TEST RESULT '${status_upper}': ${__BASHLOG_TEST_NAME} (${duration_s}s) ${msg_suffix}";
      ;;
  esac

  __BASHLOG_TEST_NAME="";
  __BASHLOG_TEST_START_S=0;
}

function log_test_end() {
  _bashlog__test_end_core "${@}";
}

function log_test_pass() { _bashlog__test_end_core 'PASS' "${@}"; }
function log_test_fail() { _bashlog__test_end_core 'FAIL' "${@}"; }
function log_test_skipped() { _bashlog__test_end_core 'SKIPPED' "${@}"; }
function log_test_error() { _bashlog__test_end_core 'ERROR' "${@}"; }
function log_test_timeout() { _bashlog__test_end_core 'TIMEOUT' "${@}"; }

function log_suite_end() {
  local now_s="$(date +%s)";
  local duration_s=0;
  if [ "${__BASHLOG_SUITE_START_S}" -gt 0 ]; then
    duration_s=$(( now_s - __BASHLOG_SUITE_START_S ));
  fi;
  local total=$(( __BASHLOG_COUNT_PASS + __BASHLOG_COUNT_FAIL + __BASHLOG_COUNT_SKIP + __BASHLOG_COUNT_ERROR + __BASHLOG_COUNT_TIMEOUT ));

  local logs_hint="";
  if [ "${BASHLOG_FILE:-0}" -eq 1 ]; then
    logs_hint+=" file=${BASHLOG_FILE_PATH:-/tmp/$(basename "${0}").log}";
  fi;
  if [ "${BASHLOG_JSON:-0}" -eq 1 ]; then
    logs_hint+=" json=${BASHLOG_JSON_PATH:-/tmp/$(basename "${0}").log.json}";
  fi;

  if [ "${__BASHLOG_COUNT_FAIL}" -gt 0 ]; then
    log fail "SUITE END: ${__BASHLOG_SUITE_NAME} (${duration_s}s) pass=${__BASHLOG_COUNT_PASS} fail=${__BASHLOG_COUNT_FAIL} skipped=${__BASHLOG_COUNT_SKIP} error=${__BASHLOG_COUNT_ERROR} timeout=${__BASHLOG_COUNT_TIMEOUT} total=${total}${logs_hint}";
  else
    log pass "SUITE END: ${__BASHLOG_SUITE_NAME} (${duration_s}s) pass=${__BASHLOG_COUNT_PASS} fail=${__BASHLOG_COUNT_FAIL} skipped=${__BASHLOG_COUNT_SKIP} error=${__BASHLOG_COUNT_ERROR} timeout=${__BASHLOG_COUNT_TIMEOUT} total=${total}${logs_hint}";
  fi;
}
