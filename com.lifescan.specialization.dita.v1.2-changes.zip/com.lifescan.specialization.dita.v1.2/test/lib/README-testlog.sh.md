# testlog.sh

A powerful logging and test reporting library for bash scripts.

## Quick Start

1. Source the library in your script:
```bash
. testlog.sh
```

2. Use logging functions:
```bash
log info "Operation completed"
log error "Something went wrong"
log debug "Debug information"
log warn "Warning message"
```

## Features

### Log Levels and Thresholds

Each output sink (stdout, file, json, syslog) has its own configurable level threshold:
- `BASHLOG_STD_LEVEL`: Console output (default: INFO)
- `BASHLOG_FILE_LEVEL`: File logging (default: OFF)
- `BASHLOG_JSON_LEVEL`: JSON logging (default: OFF)
- `BASHLOG_SYSLOG_LEVEL`: Syslog output (default: OFF)

Valid levels (from highest to lowest priority):
- EMERG (0)
- ALERT (1)
- CRIT (2)
- ERROR (3)
- WARN (4)
- NOTICE (5)
- INFO (6)
- DEBUG (7)

### Test Suite Support

Built-in functions for test reporting:
```bash
log_suite_start "My Test Suite"
log_test_start "Test Case 1"
log_test_pass "Optional message"  # Also: fail, error, skip, timeout
log_suite_end
```

### Configuration

Environment variables:
- `DEBUG=1`: Enable debug output and interactive debugging
- `BASHLOG_DATE_FORMAT`: Date format for logs (default: +%F %T)
- `BASHLOG_FILE_PATH`: Log file path (default: /tmp/scriptname.log)
- `BASHLOG_JSON_PATH`: JSON log path (default: /tmp/scriptname.log.json)
- `BASHLOG_SYSLOG_TAG`: Syslog tag (default: script name)
- `BASHLOG_SYSLOG_FACILITY`: Syslog facility (default: local0)

### Command Tracking

The library automatically tracks commands via a DEBUG trap, providing `prev_cmd` for logging:
```bash
some_command --with params \
  && log debug "${prev_cmd}" \
  || log error "${prev_cmd}"
```

## Example Usage

```bash
#!/bin/bash
. testlog.sh

# Configure outputs
export BASHLOG_FILE_LEVEL=DEBUG
export BASHLOG_SYSLOG_LEVEL=INFO

# Test suite example
log_suite_start "API Tests"

log_test_start "Database Connection"
if ping -c 1 database.local; then
  log_test_pass
else
  log_test_fail "Database unreachable"
fi

log_test_start "API Authentication"
curl -s api/auth \
  && log_test_pass "Auth endpoint responding" \
  || log_test_fail "Auth failed"

log_suite_end

# Regular script logging
log info "Starting backup process"
tar -czf backup.tar.gz /data \
  && log debug "${prev_cmd}" \
  || log error "Backup failed"

# Debug shell on error (when DEBUG=1)
rm -rf /nonexistent \
  && log debug "Cleanup successful" \
  || log error "Cleanup failed"
```