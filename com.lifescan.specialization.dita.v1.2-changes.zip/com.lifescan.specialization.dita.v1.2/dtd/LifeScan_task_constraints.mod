<?xml version="1.0" encoding="UTF-8"?>
<!-- ============================================================= -->
<!-- LifeScan Task Constraints Module                               -->
<!-- Purpose: Centralize taskbody constraints for LifeScan shells    -->
<!-- Includes OASIS Strict Taskbody Constraint; extend here as needed-->
<!-- ============================================================= -->

<!-- OASIS DITA 1.2 strict taskbody constraint -->
<!ENTITY % strictTaskbody-c-def  PUBLIC "-//OASIS//ELEMENTS DITA 1.2 Strict Taskbody Constraint//EN" "technicalContent/dtd/strictTaskbodyConstraint.mod">
%strictTaskbody-c-def;

