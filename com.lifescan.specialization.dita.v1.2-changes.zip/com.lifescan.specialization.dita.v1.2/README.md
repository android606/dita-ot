# LifeScan DITA 1.2 Specialization Plugin

## Overview

The plugin extends standard DITA 1.2 with LifeScan-specific attributes and constraints.
The full OASIS DITA 1.2 plugin is also included. If you have that plugin installed, you must remove it first.

## Specializations

### Custom Attributes

Profiling attributes:
- **`supportedproducts`** - Include content only when specific products are supported
- **`itemtype`** - Include content only for a specific type of publication (carton, manual, etc) 
- **`available`** - Include content only when specific other items are available
- **`included`** - Include content only when specific other items are included with the product

Metadata attribute: 
- **`feature`** - Identifies content relevant to a product feature (for launchdarkly flags)

Processing attribute:
- **`deliveryTarget`** - Specifies the intended media; print, screen, etc. (From DITA 1.3)

### Document Types

The plugin provides specialized DTDs for:

- **`LifeScan_bookmap.dtd`** - BookMap specialization with LifeScan attributes
- **`LifeScan_map.dtd`** - Map specialization with LifeScan attributes
- **`LifeScan_topic.dtd`** - Base topic specialization
- **`LifeScan_concept.dtd`** - Concept topic specialization
- **`LifeScan_task.dtd`** - Task topic specialization
- **`LifeScan_reference.dtd`** - Reference topic specialization

### Character Entities

Custom character entities for LifeScan documentation:
**Currency & Financial:**
- `&cent;` (¢) - Cent symbol
- `&pound;` (£) - Pound sterling
- `&euro;` (€) - Euro symbol

**Mathematical & Comparison:**
- `&le;` (≤) - Less than or equal to
- `&ge;` (≥) - Greater than or equal to
- `&plusmn;` (±) - Plus-minus sign
- `&divide;` (÷) - Division sign
- `&times;` (×) - Multiplication sign
- `&deg;` (°) - Degree symbol
- `&micro;` (µ) - Micro symbol

**Punctuation & Typography:**
- `&emdash;` (—) - Em dash
- `&endash;` (–) - En dash
- `&mdash;` (—) - Em dash (alternative)
- `&ndash;` (–) - En dash (alternative)
- `&ldquo;` (") - Left double quotation mark
- `&rdquo;` (") - Right double quotation mark
- `&lsquo;` (') - Left single quotation mark
- `&rsquo;` (') - Right single quotation mark
- `&iexcl;` (¡) - Inverted exclamation mark
- `&iquest;` (¿) - Inverted question mark
- `&nbhyphen;` (‑) - Non-breaking hyphen

**Special Characters:**
- `&reg;` (®) - Registered trademark
- `&trade;` (™) - Trademark symbol
- `&nbsp;` ( ) - Non-breaking space
- `&wordjoiner;` () - Word joiner (zero-width character)

**UI & Interactive Elements:**
- `&ballotbox;` (☐) - Empty ballot box
- `&ballotboxwithx;` (☑) - Ballot box with check mark
- `&ballotboxwithch;` (☒) - Ballot box with X mark
- `&whitecircle;` (○) - White circle
- `&warning;` (⚠) - Warning symbol

**Control Characters:**
- `&amp;` (&) - Ampersand
- `&lt;` (<) - Less than
- `&gt;` (>) - Greater than
- `&br;` - Line break
- `&cr;` - Carriage return
- `&newline;` - New line
- `&tab;` - Tab character

## Constraints

### Content Filtering

The plugin enables content filtering based on:
- Product support (`supportedproducts` attribute)
- Content availability (`available` attribute)
- Feature inclusion (`feature` attribute)
- Delivery targets (`deliveryTarget` attribute)

### Validation

- All LifeScan specializations extend standard DITA 1.2 elements
- Custom attributes are optional (CDATA, #IMPLIED)
- Maintains compatibility with standard DITA tools

## Usage

### Public Identifiers

Use the following public identifiers for LifeScan specializations:

```
PUBLIC "-//LIFESCAN//DTD DITA BookMap//EN" "LifeScan_bookmap.dtd"
PUBLIC "-//LIFESCAN//DTD DITA Map//EN" "LifeScan_map.dtd"
PUBLIC "-//LIFESCAN//DTD DITA Topic//EN" "LifeScan_topic.dtd"
PUBLIC "-//LIFESCAN//DTD DITA Concept//EN" "LifeScan_concept.dtd"
PUBLIC "-//LIFESCAN//DTD DITA Task//EN" "LifeScan_task.dtd"
PUBLIC "-//LIFESCAN//DTD DITA Reference//EN" "LifeScan_reference.dtd"
```

There are also fallback definitions in the catalog to support old files using 
the //OASIS// identifiers.

## Dependencies

- Java 8+
- DITA Open Toolkit 3.7.3+
- Warning: The standard DITA 1.2 plugin (`org.oasis-open.dita.v1_2`) conflicts with 
  this plugin and MUST NOT be installed.

## Installation and Integration

### Standard Installation

This plugin works with the standard DITA-OT installation process:

```bash
# Install the plugin using standard DITA-OT command
bin/dita install your-plugin-file.zip
```

## Building from Source

```bash
# From source root directory
./build.sh
```

## Running tests

See `test/README.md`

## Plugin Files

- `dtd/catalog.xml` - DTD-specific catalog
- `dtd/LifeScan_*.dtd` - Specialized DTD files
- `dtd/LifeScan_*.mod` - Specialized module files
- `dtd/LifeScan_*.ent` - Entity definition files
- `catalog.xml` - Main plugin catalog
- `plugin.xml` - Plugin configuration with integration extension
- `build-dita.xml` - Ant script for the 'validate-1.2' source file validator transtype
- `README.md` - This document