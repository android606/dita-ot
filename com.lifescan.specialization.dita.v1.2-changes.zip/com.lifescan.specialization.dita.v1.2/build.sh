#!/bin/bash
#
# LifeScan DITA 1.2 Specialization Plugin build and package script
#
# See README-build.md for more information
#

set -e  # Exit on any error

# Script configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
BUILD_FILE="build.xml"
REQUIRED_JAVA_VERSION=8

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check Java version
check_java() {
    local java_exec="java";
    if command_exists java; then
        java_exec="java";
    elif command_exists javac; then
        java_exec="javac";
    elif command_exists java.exe; then # For WSL compatibility
        java_exec="java.exe";
    else
        log_error "Java is not installed or not in PATH"
        return 1
    fi
    
    local java_version_string
    local java_major_version
    
    java_version_string=$(${java_exec} -version 2>&1 | head -n 1 | awk -F '"' '{print $2}')
    
    # Handle both old format (1.8.0_xxx) and new format (11.0.x, 17.0.x)
    if [[ "$java_version_string" =~ ^1\.([0-9]+) ]]; then
        java_major_version="${BASH_REMATCH[1]}"
    else
        java_major_version=$(echo "$java_version_string" | awk -F '.' '{print $1}')
    fi
    
    if [[ "$java_major_version" -lt "$REQUIRED_JAVA_VERSION" ]]; then
        log_error "Java $REQUIRED_JAVA_VERSION or higher is required (found Java $java_major_version from $java_version_string)"
        return 1
    fi
    
    log_info "Java version check passed (Java $java_major_version from $java_version_string)"
    return 0
}

# Function to set up Ant and Ant-contrib
setup_ant() {
    local ant_cmd=""
    local ant_contrib_jar="ant-contrib-1.0b3.jar"
    local ant_contrib_url="https://repo1.maven.org/maven2/ant-contrib/ant-contrib/1.0b3/ant-contrib-1.0b3.jar"
    local ant_dir="$PROJECT_DIR/tools/ant"
    local ant_lib_dir="$ant_dir/lib"
    local temp_dir="$PROJECT_DIR/temp"
    local system_ant_ok=false
    
    log_info "Setting up Ant and Ant-contrib..."
    
    # Check if system Ant exists and has Ant-contrib
    if command_exists ant; then
        log_info "System Ant found: $(which ant)"
        
        # Get system Ant lib directory
        local system_ant_home=$(dirname "$(dirname "$(which ant)")")
        local system_ant_lib="$system_ant_home/lib"
        
        # Check if Ant-contrib exists in system Ant
        if [[ -f "$system_ant_lib/$ant_contrib_jar" ]]; then
            log_info "System Ant has Ant-contrib installed"
            ant_cmd="ant"
            ant_lib_dir="$system_ant_lib"
            system_ant_ok=true
        else
            log_info "System Ant is missing Ant-contrib"
        fi
    else
        log_info "System Ant not found"
    fi
    
    # If system Ant with Ant-contrib is available, use it
    if [[ "$system_ant_ok" == true ]]; then
        log_info "Using system Ant with Ant-contrib"
        export ANT_CMD="$ant_cmd"
    else
        # Otherwise, set up local Ant installation
        log_info "Setting up local Ant installation with Ant-contrib"
        
        # Create directories
        mkdir -p "$ant_lib_dir"
        mkdir -p "$temp_dir"
        
        # Download Ant-contrib
        log_info "Downloading Ant-contrib..."
        
        if command_exists curl; then
            curl -L --fail --silent --show-error "$ant_contrib_url" -o "$temp_dir/$ant_contrib_jar"
        elif command_exists wget; then
            wget --quiet "$ant_contrib_url" -O "$temp_dir/$ant_contrib_jar"
        else
            log_error "Neither curl nor wget is available to download Ant-contrib"
            return 1
        fi
        
        # Check if download was successful
        if [[ ! -f "$temp_dir/$ant_contrib_jar" ]]; then
            log_error "Failed to download Ant-contrib"
            return 1
        fi
        
        # Copy Ant-contrib to lib directory
        cp "$temp_dir/$ant_contrib_jar" "$ant_lib_dir/"
        log_success "Ant-contrib installed at: $ant_lib_dir/$ant_contrib_jar"
        
        # Check if we have a local DITA-OT with Ant
        if [[ -f "$PROJECT_DIR/dita-ot/bin/ant" ]]; then
            log_info "Using DITA-OT Ant"
            ant_cmd="$PROJECT_DIR/dita-ot/bin/ant"
        elif [[ -f "$PROJECT_DIR/dita-ot/bin/ant.bat" ]] && [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
            log_info "Using DITA-OT Ant (Windows)"
            ant_cmd="$PROJECT_DIR/dita-ot/bin/ant.bat"
        else
            # If no local Ant, check if system Ant exists (without Ant-contrib)
            if command_exists ant; then
                log_info "Using system Ant with local Ant-contrib"
                ant_cmd="ant"
            else
                log_error "No Ant installation found. Please install Ant or ensure DITA-OT is available."
                return 1
            fi
        fi
        
        # Set ANT_CMD with explicit lib path
        export ANT_CMD="$ant_cmd -lib $ant_lib_dir"
        
        # Clean up
        rm -rf "$temp_dir"
    fi
    
    # Test Ant
    if ! $ANT_CMD -version >/dev/null 2>&1; then
        log_error "Ant is not working properly"
        return 1
    fi
    
    log_info "Ant version: $($ANT_CMD -version | head -n1)"
    
    # Verify Ant-contrib
    log_info "Verifying Ant-contrib installation..."
    local test_file="$PROJECT_DIR/ant-contrib-test.xml"
    
    # Create a simple Ant build file to test ant-contrib
    cat > "$test_file" << EOF
<project name="ant-contrib-test" default="test">
    <taskdef resource="net/sf/antcontrib/antlib.xml"/>
    
    <target name="test">
        <if>
            <equals arg1="true" arg2="true"/>
            <then>
                <echo message="Ant-contrib is working properly"/>
            </then>
            <else>
                <echo message="Ant-contrib is not working"/>
            </else>
        </if>
    </target>
</project>
EOF
    
    # Run the test
    if $ANT_CMD -f "$test_file" >/dev/null 2>&1; then
        log_success "Ant-contrib is working properly"
        rm -f "$test_file"
    else
        log_error "Ant-contrib verification failed"
        rm -f "$test_file"
        return 1
    fi
    
    return 0
}

# Function to run Ant build
run_ant_build() {
    local target="${1:-build}"
    local additional_args="${2:-}"
    
    log_info "Running Ant build target: $target"
    
    cd "$PROJECT_DIR"
    
    # Build the command
    local build_cmd="$ANT_CMD -f $BUILD_FILE $target"
    
    # Add additional arguments if provided
    if [[ -n "$additional_args" ]]; then
        build_cmd="$build_cmd $additional_args"
    fi
    
    log_info "Executing: $build_cmd"
    
    # Run the build
    if eval "$build_cmd"; then
        log_success "Ant build completed successfully"
        return 0
    else
        log_error "Ant build failed"
        return 1
    fi
}

# Function to display usage
usage() {
    echo "Usage: $0 [OPTIONS] [TARGET]"
    echo ""
    echo "Platform-independent packaging script for LifeScan DITA plugin"
    echo ""
    echo "TARGETS:"
    echo "  build        Clean, Stage, and Create full plugin ZIP package (default)"
    echo "  clean        Clean build artifacts"
    echo "  stage        Stage plugin files for packaging"
    echo "  package      Create plugin ZIP package from staged files"
    echo ""
    echo "OPTIONS:"
    echo "  -h, --help              Show this help"
    echo "  --verbose               Enable verbose output"
    echo ""
    echo "EXAMPLES:"
    echo "  $0                      # Run 'build' target and create standard package"
    echo "  $0 clean                # Clean build artifacts"
    echo ""
    echo "ENVIRONMENT VARIABLES:"
    echo "  BUILD_VERSION          Override plugin version"
    echo "  ANT_OPTS                Additional Ant JVM options"
    echo ""
}

# Function to check all dependencies
check_dependencies() {
    log_info "Checking dependencies..."
    
    local deps_ok=true
    
    # Check Java
    if ! check_java; then
        deps_ok=false
    fi
    
    # Check Ant
    if ! setup_ant; then
        deps_ok=false
    fi
    
    # Check build file
    if [[ ! -f "$PROJECT_DIR/$BUILD_FILE" ]]; then
        log_error "Build file not found: $PROJECT_DIR/$BUILD_FILE"
        deps_ok=false
    fi
    
    # Check plugin.xml
    if [[ ! -f "$PROJECT_DIR/plugin.xml" ]]; then
        log_error "Plugin descriptor not found: '$PROJECT_DIR/plugin.xml'"
        deps_ok=false
    fi
    
    if [[ "$deps_ok" == true ]]; then
        log_success "All dependencies are available"
        return 0
    else
        log_error "Some dependencies are missing"
        return 1
    fi
}

# Main function
main() {
    local target="build"
    local additional_args=""
    local verbose=false
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                usage
                exit 0
                ;;
            --verbose)
                verbose=true
                shift
                ;;
            -*|--*)
                log_error "Unknown option $1"
                usage
                exit 1
                ;;
            *)
                target="$1"
                shift
                ;;
        esac
    done
    
    # Enable verbose output if requested
    if [[ "$verbose" == true ]]; then
        additional_args="$additional_args -verbose"
    fi
    
    # Set plugin version if provided
    if [[ -n "$BUILD_VERSION" ]]; then
        additional_args="$additional_args -Dbuild.version=$BUILD_VERSION"
    fi
    
    log_info "LifeScan DITA 1.2 Specialization Plugin Packaging Script"
    log_info "========================================================="
    
    # Check dependencies
    if ! check_dependencies; then
        exit 1
    fi
    
    # Run the build
    if run_ant_build "$target" "$additional_args"; then
        log_success "Packaging completed successfully!"
        
        # Show output files if they exist
        if [[ -d "$PROJECT_DIR/dist" ]]; then
            log_info "Output file:"
            ls -a "$PROJECT_DIR/dist/"*.zip 2>/dev/null || log_info "No ZIP files found in dist/"
        fi
        
        exit 0
    else
        log_error "Packaging failed!"
        exit 1
    fi
}

# Run main function with all arguments
main "$@"
